#include "main.h"
#ifdef APPLICATION_OEM
#define _SUPPRESS_PLIB_WARNING
#define _DISABLE_OPENADC10_CONFIGPORT_WARNING

#include <stdio.h>
#include <time.h>
#include "onBoardADC.h"
#include "sd_spi.h"
#include "display.h"
#include "delay.h"
#include "log.h"
#include "math.h"
#include "readConfig.h"
#include "onBoardRTCC.h"
#include "appOEM.h"


extern int lowestCoolerTemp;
extern int highestCoolerTemp;
extern int lowestHeaterTemp;
extern int highestHeaterTemp;
extern int lowestGasPressure;
extern int highestGasPressure;

extern struct timespec currentTime;

extern int displayTime;

void Display(oemStruct * os)
{
#ifdef DISPLAY
    if(DIO0_IN)
    {
        os->displayChange = 0;
        if(currentTime.tv_sec < displayTime)
        {
            if((currentTime.tv_sec + 60) > (displayTime + DISPLAY_CHNG_TIME))
            {
                os->displayChange = 1;
            }
        }
        else if(currentTime.tv_sec > (displayTime + DISPLAY_CHNG_TIME))
        {
            os->displayChange = 1;
        }

        if(1 == os->displayChange)
        {
            displayTime = currentTime.tv_sec;
            os->displayPage++;
            if(3 == os->displayPage)
            {
                os->displayPage = 1;
            }
        }

        os->pageChngEn = 0;
    }
    else
    {
        if(adcresult[0] <= 2048)
        {
            os->displayPage = 1;
        }
        else
        {
            os->displayPage = 2;
        }

        os->pageChngEn = 1;
    }

    if(1 == os->displayPage)
    {
        DisplayParameterAndIntValue("Key Status", os->keyStatus);            
        DisplayParameterAndIntValue("Heater Celsius", os->tcAvg);
        DisplayParameterAndIntValue("Engine Celsius", os->tempSensor);
        //DisplayParameterAndIntValue("MaxTopPres", maxTopPressure);
        //DisplayParameterAndIntValue("MinTopPres", minTopPressure);
        DisplayParameterAndIntValue("PressureNow", os->pressAvg);
        DisplayParameterAndIntValue("CirculationPump", os->circulationPump);   
        DisplayParameterAndIntValue("InverterStatus", os->inverterStatus);  
        DisplayParameterAndIntValue("Is_sdcard_ok", os->is_sdcard_ok);          
        DisplayParameterAndIntValue("SD mount", os->sd_mount);
        DisplayParameterAndIntValue("ErrorCode", os->errorCode);
        DisplayDateTime();
        DisplayRestartScreen();
    }
    else if(2 == os->displayPage)
    {  

        DisplayParameterAndIntValue("InverterOnCounter", os->inverterOnCounter);
        DisplayParameterAndIntValue("InverterOffCounter", os->inverterOffCounter);             
        DisplayParameterAndIntValue("LogReturn", os->logReturn);
        DisplayParameterAndIntValue("LastLogReturn", os->lastLogReturn); 
        DisplayParameterAndIntValue("lowCoolerTemp", lowestCoolerTemp);
        DisplayParameterAndIntValue("highCoolerTemp", highestCoolerTemp);
        DisplayParameterAndIntValue("lowHeaterTemp", lowestHeaterTemp);
        DisplayParameterAndIntValue("highHeaterTemp", highestHeaterTemp);
        DisplayParameterAndIntValue("lowGasPressure", lowestGasPressure);
        DisplayParameterAndIntValue("highGasPressure", highestGasPressure);
        DisplayRestartScreen();
    }
#endif    
}

#endif
