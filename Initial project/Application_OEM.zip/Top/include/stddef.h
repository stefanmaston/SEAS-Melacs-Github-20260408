/******************************************************************************
*
*                            Unison and DSPnano
*  Copyright 1987-2013 Multiprocessor Toolsmiths, Inc., RoweBots Research Inc.
*                           ALL RIGHTS RESERVED
*
*   This computer program is the property of RoweBots Research Inc.,
*   Kitchener, Ontario Canada. and may not be copied or redistributed in any 
*   form or by any means, whether in part or in whole, except under license 
*   granted by RoweBots Research Inc.
*
*   All copies of this program, whether in part or in whole, and whether 
*   modified or not, must display this and all other embedded copyright and 
*   ownership notices in full.  This notice may not be modified.
*
*   All source code is protected by international copyright laws and license
*   agreements.  Do not break the law.  You can obtain a license and source
*   code at rowebots.com subject to licensing conditions and restrictions.
*   Free development, free source code and free non commercial licenses may
*   be obtained in a few seconds on line without any difficult process.
*
*   All demonstration programs may be redistributed as source code to others  
*   as a small part of a Unison or DSPnano application. 
*
* ******************************************************************************   
*
*
*   Save Time and Money.  If you need modifications to the software to support
*   specific processors or peripherals, RoweBots Research can do this for you
*   quickly and easily at low cost.  If you need help with application develop-
*   ment, again we can solve your embedded development problems quickly and 
*   easily at very attractive prices.  We are tiny tiny embedded Linux* experts,
*   let us reduce your risk, accelerate your development and slash your time 
*   to market.  See rowebots.com - contact us.
*
*
*******************************************************************************/

#ifndef _stddef_h_
#define _stddef_h_

#ifdef __cplusplus
extern "C" {
#endif

#include <bits/local_lim.h>

#ifndef NULL
#define NULL	((void*)0)
#endif

#ifndef _SIZE_T
#define _SIZE_T
typedef unsigned int size_t;
#endif

#ifdef __REDEFINE_PTRDIFF
#ifndef _PTRDIFF_T
#define _PTRDIFF_T
typedef signed int ptrdiff_t;
#endif
#endif	//__REDEFINE_PTRDIFF

#ifdef __REDEFINE_WCHAR
# ifndef _WCHAR_T
# define _WCHAR_T
	#ifndef __cplusplus
  	typedef int wchar_t;
	#endif  
# endif
#endif // __REDEFINE_WCHAR

//According to ISO and Posix wint_t should be defined in <wchar.h>,
//but some compiler, defining wint_t in <stddef.h>.
//So we will define wint_t in <stddef.h> and <wchar.h>
#ifdef __REDEFINE_WINT
# ifndef _WINT_T
# define _WINT_T
 typedef unsigned int wint_t;
# endif
#endif //__REDEFINE_WINT

//not defined in Unison yet
//#define offsetof(type, member-designator)	 

#ifdef __cplusplus
} //extern "C" {
#endif

#endif /* _stddef_h_ */
